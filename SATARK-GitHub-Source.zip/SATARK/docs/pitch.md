# SATARK pitch
India's retail investor base is expanding, but access to financial information can outpace financial confidence. A first-time investor may encounter an urgent message that sounds authoritative without knowing what to check.

SATARK serves people like Ramesh, 62, in Gorakhpur. He can paste or speak a financial message and receive an explanation of its safety signals in Hindi or English. The product shows the actual matching language, how the score was formed, what remains unverified and the next independent checks to make.

The differentiator is voice-first interaction, a Bharat-focused user journey, explainable detection and limited data retention. SATARK provides no investment advice.

The working prototype includes deterministic bilingual analysis, speech adapters, example scenarios, local OCR and a basic-phone simulation. Live registry verification, telecom, Bhashini, Whisper and a trained classifier are future work. The hosted demo uses a TypeScript API; the Python backend is separately runnable.

Evaluation plan: measure missed dangerous claims and false positives on labeled bilingual messages; test comprehension and task completion with senior users; assess whether users can identify what still needs independent verification. No measured accuracy or prevented losses are claimed yet.

Team Neural Nexus: Aryan Tiwari, Machine Learning; Dheer Mehta, Full Stack; Devansh Upadhyay, DevOps.
