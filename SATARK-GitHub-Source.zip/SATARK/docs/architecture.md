# Architecture

React PWA → text / browser ASR → rule engine → bilingual template explanation → browser TTS.

The deployment has a Worker-compatible TypeScript API. Local Python deployment uses FastAPI. Both engines consume the same `shared/rules.json` and have parity tests. Screenshots can pass through a configured server-side proxy to Python/Tesseract; otherwise the hosted interface offers explicit manual transcription.

`POST /api/analyze`: JSON `{ "text": "..." }`; returns score, level, signal evidence, extracted statements, verification and engine version. Text limit 5,000 characters. No storage.

`POST /api/telephony/simulate`: same contract and engine; simulation only. A future real telephony adapter must authenticate provider callbacks and handle consent before calling this engine.

`POST /api/ocr`: image multipart in local Python deployment, 5 MB and 16 million pixel caps; temporary file cleanup; 30-second OCR timeout; returns text and review-required flag. Hosted proxy returns 503 when not configured.

Evidence connector statuses: VERIFIED, NOT VERIFIED, UNABLE TO VERIFY. Current connector always returns UNABLE TO VERIFY. A future connector must carry retrieved source, timestamp and exact evidence; an LLM is not an evidence source.

No LLM or XGBoost is presently implemented. Sentence splitting is claim extraction only in the basic literal sense. It performs no semantic fact-checking.

The ASR/TTS adapter boundaries permit future Bhashini/Whisper integration without changing the risk engine. Additional languages require reviewed translations and detection evaluation.

No database or persistent files for user messages. The service worker deliberately does not cache messages, API responses or authenticated documents. Public production deployment still requires rate limiting, monitoring without sensitive body logs and abuse review.
