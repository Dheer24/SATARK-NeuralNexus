# Jury questions

**Why rules instead of an LLM?** They run without keys, give reproducible results and expose exact evidence. We have no evaluated training data to justify a trained classifier. An optional LLM could simplify text later, but cannot establish registry truth or change the rule evidence.

**Is 87 a fraud probability?** No. It is the sum of five transparent heuristic weights. It is not calibrated. We show uncertainty and never certify safety from a low score.

**Did you verify SEBI registration?** No. The interface reports UNABLE TO VERIFY, links to the official website and has a connector abstraction ready for an authoritative source. No fabricated matches.

**Does it work on a basic phone?** The current app simulates the interaction. A real telecom provider, callback service, consent flow and regional ASR/TTS remain to be connected. We do not claim basic-phone deployment today.

**What happens to data?** No message database or analytics. Text is transient; local OCR cleans temporary files. Browser voice services may send audio to their provider. Infrastructure may retain normal network metadata.

**Can it miss a scam?** Yes. Rule coverage, negation, paraphrases, multilingual phrasing and contextual ambiguity limit accuracy. It cannot authenticate a person, image, link or financial claim.

**How does screenshot input work?** The hosted demo previews the image and requires manual transcription, explicitly labeled. The included Python backend performs real local Tesseract OCR when configured. Users review extracted text.

**Is it a PWA?** A manifest and minimal service worker are present. Full offline reload is not implemented; browser installation support varies. User messages are not cached.

**What is the next experiment?** Evaluate false negatives and false positives on a labeled bilingual corpus, then test whether first-time users understand the reasons and uncertainty.
