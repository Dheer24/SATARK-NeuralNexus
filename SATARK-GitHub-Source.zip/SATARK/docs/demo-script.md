# Ramesh's pause: 3–5 minute demo

**0:00–0:35 — The person.** Ramesh is 62 and lives in Gorakhpur. He is more comfortable with Hindi than financial jargon. A forwarded message promises 40% in seven days and asks him to pay a personal UPI ID. Instead of paying, he pauses.

**0:35–1:05 — The message.** Open SATARK, choose Try a demo, select the first message. Read the claim and press Analyze. This is an illustrative scenario, not a real fraud report.

**1:05–2:00 — The reasons.** Show HIGH RISK and 87/100. Explain the sum: guarantee 25, short-term return 17, urgency 15, scarcity 5, personal payment 25. Expand extracted statements. Say: this is a safety-signal score, not an 87% probability of fraud. The exact matching phrases are visible.

**2:00–2:40 — Language and evidence.** Switch to Hindi. Press Listen, with a Hindi voice installed ahead of the presentation. If unavailable, show the honest device-support message and read the Hindi explanation. Show UNABLE TO VERIFY: we have not connected a live registry. We do not manufacture registration results.

**2:40–3:15 — Nuance.** Load the educational volatility example and Analyze. Show zero detected signals and the warning that this does not guarantee safety. Load the registration example if time allows: NEEDS VERIFICATION.

**3:15–4:00 — Reach.** Open Basic phone mode. Say clearly: this is an in-app simulation of our planned missed-call service. Simulate the call, speak or load a demo, analyze, listen. There is no real telecom integration today.

**4:00–4:30 — Close.** SATARK gives first-time investors a way to pause, understand suspicious claims and independently verify before transferring money. No tips, no recommendations, no paid upsells. Verify before you transfer.
