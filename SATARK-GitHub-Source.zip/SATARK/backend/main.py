"""Stateless reference FastAPI backend. Never log request bodies."""
import json, re, os, subprocess, tempfile
from pathlib import Path
from typing import Literal
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, StrictStr, Field
RULES=json.loads((Path(__file__).parent.parent/'shared/rules.json').read_text())
app=FastAPI(title='SATARK',version='1.0.0')
app.add_middleware(CORSMiddleware,allow_origins=os.getenv('ALLOWED_ORIGINS','http://localhost:3000').split(','),allow_methods=['POST','GET'],allow_headers=['Content-Type'])
class Input(BaseModel):
    text: StrictStr=Field(min_length=1,max_length=5000)
class Verification(BaseModel):
    status: Literal['VERIFIED','NOT VERIFIED','UNABLE TO VERIFY']
    reason: str
class RegistryConnector:
    def verify(self,text:str)->Verification:
        return Verification(status='UNABLE TO VERIFY',reason='No live authoritative registry is connected. No entity, registration or claim has been authenticated.')
registry=RegistryConnector()
def analyze(text):
    if not isinstance(text,str) or not text.strip() or len(text)>5000:
        raise ValueError('Enter a message between 1 and 5,000 characters.')
    sentences=[s for s in re.split(r'(?<=[.!?।\n])\s*',text.strip()) if s]
    signals=[]
    for rule in RULES:
        for sentence in sentences:
            match=re.search(rule['pattern'],sentence,re.I)
            if match and not re.search(r"\b(never|do not|don't|avoid|beware|no|not)\b|नहीं|मत |कभी न",sentence[max(0,match.start()-45):match.end()],re.I):
                signals.append(dict(rule,evidence=match.group()));break
    score=min(100,sum(s['points'] for s in signals))
    level='HIGH RISK' if score>=75 else 'HIGH CAUTION' if score>=50 else 'CAUTION' if score>=25 else 'NEEDS VERIFICATION' if any(s['id']=='registration_claim' for s in signals) else 'NO MAJOR RED FLAGS'
    return dict(score=score,level=level,signals=signals,claims=sentences[:8],verification=registry.verify(text).model_dump(),engine='Transparent rules v1.0')
@app.middleware('http')
async def privacy_headers(request,call_next):
    response=await call_next(request)
    response.headers['Cache-Control']='no-store'
    response.headers['X-Content-Type-Options']='nosniff'
    return response
@app.get('/health')
def health():return {'status':'ok','storage':'none'}
@app.post('/api/analyze')
@app.post('/api/telephony/simulate')
def check(body:Input):
    try:return analyze(body.text)
    except ValueError as e:raise HTTPException(400,str(e))
@app.post('/api/ocr')
async def ocr(file:UploadFile=File(...)):
    """Local Tesseract only; delete temporary files immediately after processing."""
    if file.content_type not in ['image/png','image/jpeg','image/webp']:raise HTTPException(415,'Use PNG, JPG or WebP.')
    data=await file.read(5*1024*1024+1)
    if len(data)>5*1024*1024:raise HTTPException(413,'Maximum size is 5 MB.')
    try:
        from PIL import Image
        import io
        with Image.open(io.BytesIO(data)) as image:
            if image.width*image.height>16000000:raise HTTPException(413,'Image dimensions too large.')
            image.verify()
        with tempfile.TemporaryDirectory(prefix='satark-ocr-') as folder:
            source=Path(folder)/'input';source.write_bytes(data)
            languages=subprocess.run(['tesseract','--list-langs'],capture_output=True,text=True,timeout=5).stdout
            language='eng+hin' if '\nhin\n' in languages else 'eng'
            process=subprocess.run(['tesseract',str(source),'stdout','-l',language],capture_output=True,text=True,timeout=30)
            if process.returncode:raise ValueError()
            return {'text':process.stdout.strip()[:5000],'language':language,'engine':'local Tesseract','review_required':True}
    except HTTPException:raise
    except FileNotFoundError:raise HTTPException(503,'Local OCR is unavailable. Transcribe the screenshot manually.')
    except Exception:raise HTTPException(422,'Could not read this image. Try a clearer screenshot or type the message.')
