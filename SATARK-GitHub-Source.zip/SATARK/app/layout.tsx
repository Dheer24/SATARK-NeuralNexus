import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SATARK. | Verify before you transfer",
  description: "Understand suspicious financial messages in Hindi and English. Explainable safety checks by Team Neural Nexus.",
  manifest: "/manifest.webmanifest",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body className="antialiased">{children}</body>
    </html>
  );
}
