import {analyze} from '@/lib/risk';
export async function POST(request:Request){
 try {const raw=await request.text();if(raw.length>30000)return Response.json({error:'Message too large'},{status:413});const body=JSON.parse(raw);if(process.env.SATARK_BACKEND_URL){const r=await fetch(process.env.SATARK_BACKEND_URL+'/api/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body),signal:AbortSignal.timeout(5000)});if(r.ok)return Response.json(await r.json(),{headers:{'Cache-Control':'no-store'}});}return Response.json(analyze(body.text),{headers:{'Cache-Control':'no-store'}});}
 catch{return Response.json({error:'Enter a valid message of 1–5,000 characters.'},{status:400});}
}
