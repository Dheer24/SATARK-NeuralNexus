export async function POST(request:Request){
 const backend=process.env.SATARK_BACKEND_URL;
 if(!backend)return Response.json({error:'Automatic OCR is available in the local Python deployment. Please transcribe the image or use the labeled sample.'},{status:503});
 try{const length=Number(request.headers.get('content-length')||0);if(length>6*1024*1024)return Response.json({error:'Image too large'},{status:413});const response=await fetch(backend+'/api/ocr',{method:'POST',body:await request.formData(),signal:AbortSignal.timeout(35000)});return new Response(await response.text(),{status:response.status,headers:{'Content-Type':'application/json','Cache-Control':'no-store'}})}catch{return Response.json({error:'OCR unavailable. Please transcribe the image.'},{status:503})}
}
