import unittest
from backend.main import app,analyze
from fastapi.testclient import TestClient
class RiskTests(unittest.TestCase):
 def test_guaranteed(self):self.assertIn('guaranteed_return',[s['id'] for s in analyze('Guaranteed returns of 40%.')['signals']])
 def test_urgency(self):self.assertEqual(analyze('Act now. Hurry!')['score'],15)
 def test_payment(self):self.assertEqual(analyze('Send payment to personal UPI.')['score'],25)
 def test_credentials(self):self.assertEqual(analyze('Please send your OTP and password.')['score'],50)
 def test_education(self):self.assertEqual(analyze('Volatility means the price can move up or down over time.')['score'],0)
 def test_preventive(self):self.assertEqual(analyze('Never share your OTP. Do not trust guaranteed returns.')['score'],0)
 def test_hero(self):self.assertEqual(analyze('Guaranteed 40% returns in 7 days! Only 50 seats left. Send payment to this personal UPI ID today.')['score'],87)
 def test_verify(self):self.assertEqual(analyze('We are SEBI registered.')['level'],'NEEDS VERIFICATION')
 def test_hindi(self):self.assertGreaterEqual(analyze('7 दिन में 40% गारंटीड रिटर्न! सिर्फ 50 सीट बची हैं। आज ही इस निजी यूपीआई पर भुगतान करें.')['score'],75)
 def test_cap(self):self.assertEqual(analyze('Guaranteed returns. Act now. Only 4 seats. Pay personal UPI. Send OTP. Secret tip.')['score'],100)
 def test_empty(self):
  for bad in ['', '   ',None,42,{},'x'*5001]:
   with self.assertRaises(ValueError):analyze(bad)
 def test_api(self):
  with TestClient(app) as client:
   self.assertEqual(client.post('/api/analyze',json={'text':'Volatility goes up and down.'}).json()['score'],0)
   for bad in [{},{'text':[]},{'text':4},{'text':''}]:self.assertEqual(client.post('/api/analyze',json=bad).status_code,422)
   self.assertEqual(client.post('/api/analyze',content='not json').status_code,422)
   self.assertEqual(client.post('/api/telephony/simulate',json={'text':'Send your password'}).json()['score'],50)
   self.assertEqual(client.post('/api/analyze',json={'text':'hi'}).headers['cache-control'],'no-store')
if __name__=='__main__':unittest.main()
