import rules from '../shared/rules.json';
export type Lang = 'en'|'hi';
export type Signal = typeof rules[number] & {evidence:string};
export type Assessment = {score:number;level:string;signals:Signal[];claims:string[];verification:{status:'UNABLE TO VERIFY';reason:string};engine:string};
const negation = /\b(never|do not|don't|avoid|beware|no|not)\b|नहीं|मत |कभी न/iu;
export function analyze(input:unknown):Assessment {
 if(typeof input !== 'string'||!input.trim()||input.length>5000) throw new Error('Enter a message between 1 and 5,000 characters.');
 const sentences=input.trim().split(/(?<=[.!?।\n])\s*/u).filter(Boolean);
 const signals:Signal[]=[];
 for(const rule of rules){
  for(const sentence of sentences){
   const match=new RegExp(rule.pattern,'iu').exec(sentence);
   if(match && !negation.test(sentence.slice(Math.max(0,match.index-45), match.index+match[0].length))){signals.push({...rule,evidence:match[0]});break;}
  }
 }
 const score=Math.min(100,signals.reduce((sum,s)=>sum+s.points,0));
 const level=score>=75?'HIGH RISK':score>=50?'HIGH CAUTION':score>=25?'CAUTION':signals.some(s=>s.id==='registration_claim')?'NEEDS VERIFICATION':'NO MAJOR RED FLAGS';
 return {score,level,signals,claims:sentences.slice(0,8),verification:{status:'UNABLE TO VERIFY',reason:'No live authoritative registry is connected. No entity, registration or claim has been authenticated.'},engine:'Transparent rules v1.0'};
}
export const demos=[
 {id:'high',title:'The too-good-to-be-true tip',hi:'बहुत अच्छे रिटर्न का वादा',label:'HIGH RISK',text:'Guaranteed 40% returns in 7 days! Only 50 seats left. Send payment to this personal UPI ID today.',textHi:'7 दिन में 40% गारंटीड रिटर्न! सिर्फ 50 सीट बची हैं। आज ही इस निजी यूपीआई पर भुगतान करें.'},
 {id:'verify',title:'The convincing registration claim',hi:'पंजीकरण का भरोसेमंद दावा',label:'NEEDS VERIFICATION',text:'We are SEBI registered. Our research service provides financial education. Contact our team for the registration details before joining.',textHi:'हम सेबी पंजीकृत हैं। हमारी रिसर्च सेवा वित्तीय शिक्षा देती है। जुड़ने से पहले पंजीकरण की जानकारी के लिए संपर्क करें।'},
 {id:'low',title:'A little financial knowledge',hi:'वित्तीय जानकारी',label:'EDUCATIONAL',text:'Volatility means the price of an investment can move up or down over time. Higher volatility can mean larger changes in value.',textHi:'अस्थिरता का मतलब है कि निवेश का मूल्य समय के साथ ऊपर या नीचे जा सकता है। अधिक अस्थिरता में मूल्य में बड़े बदलाव हो सकते हैं।'}
];
export const levelHi:Record<string,string>={'HIGH RISK':'अधिक जोखिम','HIGH CAUTION':'अधिक सावधानी','CAUTION':'सावधानी','NEEDS VERIFICATION':'पुष्टि आवश्यक','NO MAJOR RED FLAGS':'कोई बड़ा चेतावनी संकेत नहीं'};
